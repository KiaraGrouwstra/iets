{ outputs = { self }: { v = "x"; }; }
